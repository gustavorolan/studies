package br.com.cwi.crescer.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TccApplicationTests {

	@Test
	void contextLoads() {
	}

}
