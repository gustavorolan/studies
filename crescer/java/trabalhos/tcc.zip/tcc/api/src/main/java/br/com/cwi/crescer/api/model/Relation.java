package br.com.cwi.crescer.api.model;

public enum Relation {
    FRIENDS,
    NOT_FRIENDS,
    BLOCKED,
}
