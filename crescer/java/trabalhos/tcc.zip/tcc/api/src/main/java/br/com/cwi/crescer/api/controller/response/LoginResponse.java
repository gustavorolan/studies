package br.com.cwi.crescer.api.controller.response;

import lombok.Data;

@Data
public class LoginResponse {
    private long userName;
}
