 A ideia do trabalho era fazer uma rede social para marcar jogos entre pessoas, 
 pois existe a dificuldade de fechar as duplas devido aos horarios de cada pessoa.


Mudar a senha e usuario do banco de dados, ja tiver o postgres, caso contrario tera
adicionar depedencias e fazer mais algumas configurações

Após isso, compilar executar a api pelo inteliji utilizando jdk11.

No front end é so iniciar o aplicativo, npm run start, depois disso é só criar uma conta 
e utilizar

