export { RequestPeople } from "./requestPeople/requestPeople.screen";

export { FriendsToAccept } from "./friendsToAccept/friendsListToAccept.screen";

export  { Friend } from "../components";

export { Home } from "./home/home.screen";
export { Login } from "./login/login.screen";

