export { useTccApi } from "./tccApi/use-tcc-api-hook";
