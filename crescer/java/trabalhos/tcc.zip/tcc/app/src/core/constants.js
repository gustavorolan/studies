
export const TOAST_TIME = 1500;
export const HAPPY_FACE = '☺';
export const X_TOAST ='X'

